-- use this file to map the AP item ids to your items
-- first value is the code of the target item and the second is the item type override (feel free to expand the table with any other values you might need (i.e. special inital values, increments, etc.)!)
-- here are the SM items as an example: https://github.com/Cyb3RGER/sm_ap_tracker/blob/main/scripts/autotracking/item_mapping.lua
CURRENT_ITEM = nil

ITEM_MAPPING = {

	
	-- Bosses --	
	[6554112] = {"whispy_woods", "progressive"},
	[6554113] = {"@Rock Star Boss/Pix/"},
	[6554114] = {"@Aqua Star Boss/Acro/"},
	[6554115] = {"@Neo Star Boss/Magman/"},
	[6554116] = {"@Shiver Star Boss/HR-H/"},
	[6554117] = {"@Ripple Star Boss/Miracle Matter/"},

	-- Items --

	[6553632] = {"crystal_shard", "consumable"},
	[6553633] = {"1_up", "consumable"},
	[6553634] = {"maxim_tomato", "consumable"},
	[6553635] = {"invincibility_candy", "consumable"},
    
    -- Abilities --

	[6553601] = {"burning", "toggle"},
	[6553602] = {"stone", "toggle"},
	[6553603] = {"ice", "toggle"},
	[6553604] = {"needle", "toggle"},
	[6553605] = {"bomb", "toggle"},
	[6553606] = {"spark", "toggle"},
	[6553607] = {"cutter", "toggle"},

    -- Combos --

	[6554112] = {"phoenix", "toggle"},
	[6554113] = {"volcano", "toggle"},
	[6554114] = {"burning_ice_cube", "toggle"},
	[6554115] = {"fire_arrow", "toggle"},
	[6554116] = {"fireworks", "toggle"},
	[6554117] = {"tinder_sheet", "toggle"},
	[6554118] = {"flame_sword", "toggle"},
	[6554119] = {"mega_stone", "toggle"},
	[6554120] = {"curling_stone", "toggle"},
	[6554121] = {"drill", "toggle"},
	[6554122] = {"dynamite", "toggle"},
	[6554123] = {"geokinesis", "toggle"},
	[6554124] = {"stone_friends", "toggle"},
	[6554125] = {"snowball", "toggle"},
	[6554126] = {"snowflake", "toggle"},
	[6554127] = {"exploding_snowman", "toggle"},
	[6554128] = {"refrigerator", "toggle"},
	[6554129] = {"ice_skates", "toggle"},
	[6554130] = {"clutter_needle", "toggle"},
	[6554131] = {"exploding_gordo", "toggle"},
	[6554132] = {"lightning_rod", "toggle"},
	[6554133] = {"bear_trap", "toggle"},
	[6554134] = {"rocket_launcher", "toggle"},
	[6554135] = {"lightbulb", "toggle"},
	[6554136] = {"exploding_shuriken", "toggle"},
	[6554137] = {"electrical_field", "toggle"},
	[6554138] = {"lightsaber", "toggle"},
	[6554139] = {"great_cutter", "toggle"},

	-- Friends --

	[6553856] = {"adeleine, toggle"},
	[6291714] = {"dedede, toggle"},
	[6553857] = {"waddle_dee, toggle"},
}